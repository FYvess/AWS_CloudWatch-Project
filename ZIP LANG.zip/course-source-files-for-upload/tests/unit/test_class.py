class TestClass:
    def test_one(self):
        assert 5 == 5
