from api import app # noqa
